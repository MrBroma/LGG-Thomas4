from wcwidth import list_versions


class Hangman:

    def __init__(self) -> None:
        pass


    possible_words = ['becode', 'learning', 'mathematics', 'sessions']

    word_to_find = 

    
    correctly_guessed_letters

    
